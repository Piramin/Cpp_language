﻿
// MFCApp1.h: главный файл заголовка для приложения PROJECT_NAME
//

#pragma once

#ifndef __AFXWIN_H__
	#error "включить pch.h до включения этого файла в PCH"
#endif

#include "resource.h"		// основные символы


// CMFCApp1App:
// Сведения о реализации этого класса: MFCApp1.cpp
//

class CMFCApp1App : public CWinApp
{
public:
	CMFCApp1App();

// Переопределение
public:
	virtual BOOL InitInstance();

// Реализация

	DECLARE_MESSAGE_MAP()
};

extern CMFCApp1App theApp;
