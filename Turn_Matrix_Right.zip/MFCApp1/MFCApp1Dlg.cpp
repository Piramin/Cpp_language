﻿
// MFCApp1Dlg.cpp: файл реализации
//

#include "pch.h"
#include "framework.h"
#include "MFCApp1.h"
#include "MFCApp1Dlg.h"
#include "afxdialogex.h"
#include <stdlib.h>
#include <string>



#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// Диалоговое окно CAboutDlg используется для описания сведений о приложении

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Данные диалогового окна
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // поддержка DDX/DDV

// Реализация
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// Диалоговое окно CMFCApp1Dlg



CMFCApp1Dlg::CMFCApp1Dlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_MFCAPP1_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMFCApp1Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, Enter_Function);
	DDX_Control(pDX, IDC_EDIT3, Enter_rows);
	DDX_Control(pDX, IDC_EDIT2, Enter_columns);
	DDX_Control(pDX, IDC_RADIO1, Repeat_Button);
	DDX_Control(pDX, IDC_LIST1, Print_New_Matrix);
	DDX_Control(pDX, IDC_LIST2, Print_Old_Matrix);
}

BEGIN_MESSAGE_MAP(CMFCApp1Dlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_EN_CHANGE(IDC_EDIT1, &CMFCApp1Dlg::OnEnChangeEdit1)
	ON_BN_CLICKED(IDC_BUTTON1, &CMFCApp1Dlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_RADIO1, &CMFCApp1Dlg::OnBnClickedRadio1)
END_MESSAGE_MAP()


// Обработчики сообщений CMFCApp1Dlg

BOOL CMFCApp1Dlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Добавление пункта "О программе..." в системное меню.

	// IDM_ABOUTBOX должен быть в пределах системной команды.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Задает значок для этого диалогового окна.  Среда делает это автоматически,
	//  если главное окно приложения не является диалоговым
	SetIcon(m_hIcon, TRUE);			// Крупный значок
	SetIcon(m_hIcon, FALSE);		// Мелкий значок

	// TODO: добавьте дополнительную инициализацию

	return TRUE;  // возврат значения TRUE, если фокус не передан элементу управления
}

void CMFCApp1Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// При добавлении кнопки свертывания в диалоговое окно нужно воспользоваться приведенным ниже кодом,
//  чтобы нарисовать значок.  Для приложений MFC, использующих модель документов или представлений,
//  это автоматически выполняется рабочей областью.

void CMFCApp1Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // контекст устройства для рисования

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Выравнивание значка по центру клиентского прямоугольника
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Нарисуйте значок
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// Система вызывает эту функцию для получения отображения курсора при перемещении
//  свернутого окна.
HCURSOR CMFCApp1Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CMFCApp1Dlg::OnEnChangeEdit1()
{
	// TODO:  Если это элемент управления RICHEDIT, то элемент управления не будет
	// send this notification unless you override the CDialogEx::OnInitDialog()
	// функция и вызов CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Добавьте код элемента управления
}


float fix_Matrix(int i, int j, CString function) {
	char symbols[] = { 'i','j' };
	char operations[] = { '+','-','*','/' };
	float res = 0;
	if ((function[0] == symbols[0]) && (function[2] == symbols[1])) {
		int help = i;
		if (function[0] != 'i') {
			i = j;
			j = help;
		}
		switch (function[1]) {
		case '+':
			res = i + j;
			break;
		case '-':
			res = i - j;
			break;
		case '/':
			res = i / j;
			break;
		case '*':
			res = i * j;
			break;
		}
		return res;
	}

	int sum_of_operations = 0;
	for (int j = 0; j < sizeof(operations); j++) {
		for (int i = 0; i < function.GetLength(); i++) {
			if (function[i] == operations[j]) {
				sum_of_operations++;
			}
		}
	}
	//Получение строки без символов операций:
	using namespace std;
	string string_without_operations = "";

	int keys[sizeof(symbols)];
	keys[0] = 0;
	keys[1] = 0;
	for (int i = 0; i < function.GetLength(); i++) {

		for (int j = 0; j < sizeof(operations); j++) {
			if (function[i] != operations[j]) { keys[0]++; }
		}

		if (keys[0] == sizeof(operations)) {
			string_without_operations += function[i];
			keys[1]++;
		}
		keys[0] = 0;
	}
	//Запись в массив Keys значений номеров элементов i,j... из строки без операций
	for (int j = 0; j < sizeof(keys); j++) {
		for (int i = 0; i < string_without_operations.size(); i++) {
			if (string_without_operations[i] == symbols[j]) {
				keys[j] = i;
			}
		}
	}
	//Запись в массив numbers всех чисел выражения.
	float* numbers = new float[sizeof(symbols) + 1];
	std::string number;
	int k = 0;
	while (k < string_without_operations.size()) {
		for (int j = 0; j < sizeof(keys); j++) {
			if (k == keys[j]) {
				numbers[j] = stof(number);
				number = "";
				k++;
				continue;
			}
		}
		if (k == string_without_operations.size() - 1) {
			numbers[sizeof(numbers) - 1] = stof(number);
			number = "";
		}
		number += string_without_operations[k];
		k++;
	}
	//Упрощенный вариант выражения.

	switch (function[keys[0] + 2]) {
	case '+':
		res = numbers[0] * i + numbers[1] * j;
		break;
	case '-':
		res = numbers[0] * i - numbers[1] * j;
		break;
	case '/':
		if (j != 0) { res = numbers[0] * i / (numbers[1] * j); }
		else { res = 0; };
		break;
	case '*':
		res = numbers[0] * i * numbers[1] * j;
		break;
	default:
		res = 0;
		break;
	}
	return res;

}
void CMFCApp1Dlg::OnBnClickedButton1()
{
	//Очистка диалогого окна
	Print_New_Matrix.ResetContent();
	Print_Old_Matrix.ResetContent();

	CString function_base,number_rows,number_columns;
	CString OlderMatrix, NewerMatrix, str;
	int rows, columns;
		Enter_Function.GetWindowTextW(function_base);
		Enter_rows.GetWindowTextW(number_rows);
		Enter_columns.GetWindowTextW(number_columns);
		rows = _ttoi((const wchar_t*)number_rows);
		columns = _ttoi((const wchar_t*)number_rows);

		float** Matrix = new float* [rows]; //Создается объект одномерного массива указателей(кол-во строк) на дальнейшие одномерные массивы .
		for (int j = 0; j < columns; j++) { Matrix[j] = new float[columns]; } // Создание одномерных массивов(кол-во столбцов) .

		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				Matrix[i][j] = fix_Matrix(i, j, function_base);
			}
		}
		//Создание нового массива.
		float** new_Matrix = new float* [columns];
		for (int j = 0; j < columns; j++) { new_Matrix[j] = new float[rows]; }
		//Преобразования:
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				new_Matrix[j][rows - 1 - i] = Matrix[i][j];
			}
		}
		for (int i = 0; i < rows; i++) {
			OlderMatrix = "";
			for (int j = 0; j < columns; j++) {
				//OlderMatrix = OlderMatrix + " " + str.Format(_T("%f"),Matrix[i][j]);  //Перевод
				OlderMatrix += (std::to_string(Matrix[i][j])).c_str();
				OlderMatrix += " ";
			}
			Print_Old_Matrix.AddString(OlderMatrix);
		}
		for (int i = 0; i < rows; i++) {
			NewerMatrix = "";
			for (int j = 0; j < columns; j++) {
				//NewerMatrix = NewerMatrix + " " + str.Format(_T("%f"), new_Matrix[i][j]); //Перевод
				NewerMatrix += (std::to_string(new_Matrix[i][j])).c_str();
				NewerMatrix += " ";
			}
			Print_New_Matrix.AddString(NewerMatrix);
		}
		for (int i = 0; i < rows; i++) { delete[]Matrix[i]; } //Освобождение памяти.
		for (int i = 0; i < columns; i++) { delete[]new_Matrix[i]; } //Освобождение памяти.
		delete[]Matrix; delete[]new_Matrix;

}

void CMFCApp1Dlg::OnBnClickedRadio1()
{
	// TODO: добавьте свой код обработчика уведомлений
}
